import json

# Load your JSON file
with open('merged.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# Sort by number of elements in each list (ascending)
sorted_data = dict(sorted(data.items(), key=lambda item: len(item[1])))

# Save to a new file
with open('merged.json', 'w', encoding='utf-8') as f:
    json.dump(sorted_data, f, ensure_ascii=False, indent=2)
