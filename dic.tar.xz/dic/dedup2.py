import json
import re
from pathlib import Path

try:
    from Levenshtein import ratio as lev_ratio
except ImportError:
    from rapidfuzz.distance.Levenshtein import normalized_similarity as lev_ratio


# ---------- Normalization ----------

ZERO_WIDTH = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u200e\u200f\ufeff"), None)


def normalize(s: str) -> str:
    """Normalize Persian/English text for comparison."""
    s = s.translate(ZERO_WIDTH)              # strip ZWNJ, ZWJ, LRM, RLM, etc.
    s = s.replace("ي", "ی").replace("ك", "ک")  # Arabic -> Persian chars
    s = s.replace("ۀ", "ه").replace("ة", "ه")
    s = re.sub(r"[\u064b-\u065f\u0670]", "", s)  # remove Arabic diacritics
    s = s.strip().strip(".,;:!؟?،؛").strip()
    s = re.sub(r"\s+", " ", s)               # collapse whitespace
    return s


# ---------- Dedup ----------

def dedup_list(items: list, threshold: float = 0.90) -> list:
    """
    Deduplicate a list, keeping the first occurrence.
    Two items are considered duplicates if their normalized Levenshtein
    similarity is >= threshold.
    """
    kept = []              # original items
    kept_norms = []        # normalized versions (for comparison)

    for item in items:
        if not isinstance(item, str):
            if item not in kept:
                kept.append(item)
            continue

        norm = normalize(item)
        if not norm:
            continue

        is_dup = False
        for existing_norm in kept_norms:
            if lev_ratio(norm, existing_norm) >= threshold:
                is_dup = True
                break

        if not is_dup:
            kept.append(item)
            kept_norms.append(norm)

    return kept


# ---------- Main ----------

def main():
    path = Path("merged.json")
    threshold = 0.90   # tune: 0.85 = aggressive, 0.95 = conservative

    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    deduped = {k: dedup_list(v, threshold=threshold) for k, v in data.items()}

    tmp = path.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(deduped, f, ensure_ascii=False, indent=2)
    tmp.replace(path)

    print(f"Done. Updated {path.resolve()}")


if __name__ == "__main__":
    main()