import json

INPUT = "merged.json"

# Load
with open(INPUT, 'r', encoding='utf-8') as f:
    data = json.load(f)

def should_remove(key, values):
    # Remove if key is a single letter (ignoring surrounding whitespace)
    if len(key.strip()) == 1:
        return True
    # Remove if values has exactly one item and that item is a single letter
    if len(values) == 1 and len(values[0].strip()) == 1:
        return True
    return False

# Filter
cleaned = {k: v for k, v in data.items() if not should_remove(k, v)}

removed = len(data) - len(cleaned)
print(f"Removed {removed} records. {len(cleaned)} remaining.")

# Write back in place (atomic-ish: write to temp then replace)
import os
tmp = INPUT + ".tmp"
with open(tmp, 'w', encoding='utf-8') as f:
    json.dump(cleaned, f, ensure_ascii=False, indent=2)
os.replace(tmp, INPUT)