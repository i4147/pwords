import json
from pathlib import Path


def dedup_list(items: list) -> list:
    """Deduplicate a list while preserving order."""
    seen = set()
    result = []
    for item in items:
        # Normalize for comparison (strip whitespace) but keep original
        key = item.strip() if isinstance(item, str) else item
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def main():
    path = Path("merged.json")

    # Read the JSON file
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    # Deduplicate each value list
    deduped = {key: dedup_list(values) for key, values in data.items()}

    # Write back in place (preserve unicode, pretty-print)
    with path.open("w", encoding="utf-8") as f:
        json.dump(deduped, f, ensure_ascii=False, indent=2)

    print(f"Done. Updated {path.resolve()}")


if __name__ == "__main__":
    main()