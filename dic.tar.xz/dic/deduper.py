import json
from pathlib import Path

def main():
    path = Path.cwd() / "merged.json"
    if not path.exists():
        print(f"{path.name} not found.")
        return

    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    cleaned = {}
    total_before = 0
    total_after = 0

    for word, translations in data.items():
        if not isinstance(translations, list):
            translations = [translations]

        total_before += len(translations)

        seen = set()
        deduped = []
        for entry in translations:
            if entry not in seen:
                seen.add(entry)
                deduped.append(entry)

        total_after += len(deduped)
        cleaned[word] = deduped

    with path.open("w", encoding="utf-8") as f:
        json.dump(cleaned, f, ensure_ascii=False, indent=2)

    removed = total_before - total_after
    print(f"Processed {len(cleaned)} words in {path.name}")
    print(f"Removed {removed} duplicate translation(s) "
          f"({total_before} -> {total_after})")


if __name__ == "__main__":
    main()