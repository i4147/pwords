#!/usr/bin/env python3
import sys
import json
import re
import html
from html.parser import HTMLParser

PAGE_MARKER = re.compile(r'<!\s*p\.\s*(\d+)\s*!>')

class ParagraphParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)   # required
        self.reset_state()
        self.tag_stack = []

    def reset_state(self):
        self.result = {
            'has_hw': False,
            'word': '',
            'pronunciation': '',
            'part_of_speech': '',
            'etymology': '',
            'definition': '',
            'senses': [],
            'collocations': [],
            'quotes': [],
            'notes': [],
            'is_point': False,
            'point': None,
        }
        self.current_sense = None
        self.current_collocation = None
        self.current_quote = None
        self.in_hw = self.in_pos = self.in_def = False
        self.in_sn = self.in_plw = self.in_u = self.in_grk = False
        self.in_etymology = False
        self.buffer = []


    # -------- helpers --------
    def _text(self):
        t = ''.join(self.buffer)
        self.buffer = []
        return t

    def _route(self, text):
        if not text:
            return
        # collocation definition
        if self.current_collocation is not None:
            self.current_collocation['definition'] += text
            return
        # quote
        if self.current_quote is not None:
            self.current_quote['text'] += text
            return
        # inside a sense
        if self.current_sense is not None:
            if self.in_def:
                self.current_sense['text'] += text
            else:
                # bracketed note like [Obs.] or [R.]
                self._note(text)
            return
        # headword / pos / etymology / first def
        if self.in_hw:
            self.result['word'] += text
        elif self.in_pos:
            self.result['part_of_speech'] += text
        elif self.in_etymology:
            self.result['etymology'] += text
        elif self.in_def:
            self.result['definition'] += text
        elif self.in_sn:
            # number text -> start a new sense
            num = text.strip().rstrip('.')
            if num:
                if self.current_sense is not None:
                    self._close_sense()
                self.current_sense = {'number': num, 'text': '', 'quotes': []}
        else:
            # unclassified text -> could be a note like [Obs.] or a Syn. line
            self._note(text)

    def _note(self, text):
        text = text.strip()
        if text:
            self.result['notes'].append(text)

    def _close_sense(self):
        if self.current_sense is not None:
            self.current_sense['text'] = ' '.join(self.current_sense['text'].split())
            if self.current_sense['text'] or self.current_sense['quotes']:
                self.result['senses'].append(self.current_sense)
            self.current_sense = None

    def _close_collocation(self):
        if self.current_collocation is not None:
            c = self.current_collocation
            c['phrase'] = ' '.join(c['phrase'].split())
            c['definition'] = ' '.join(c['definition'].split())
            if c['phrase']:
                self.result['collocations'].append(c)
            self.current_collocation = None

    # -------- HTMLParser hooks --------
    def handle_starttag(self, tag, attrs):
        self.tag_stack.append(tag)
        if tag == 'hw':
            self.in_hw = True
            self.result['has_hw'] = True
        elif tag == 'pos':
            self.in_pos = True
        elif tag == 'def':
            self.in_def = True
        elif tag == 'sn':
            self.in_sn = True
        elif tag == 'plw':
            self.in_plw = True
        elif tag == 'u':
            self.in_u = True
        elif tag == 'grk':
            self.in_grk = True
        elif tag == 'blockquote':
            self.current_quote = {'text': '', 'source': ''}
        elif tag == 'col':
            self._close_collocation()
            self.current_collocation = {'phrase': '', 'definition': ''}
        elif tag == 'cd':
            pass
        elif tag == 'br':
            self._route('\n')
        elif tag.startswith('point'):
            self.result['is_point'] = True
            self.result['point'] = tag

    def handle_endtag(self, tag):
        if self.tag_stack and self.tag_stack[-1] == tag:
            self.tag_stack.pop()

        if tag == 'hw':
            self.in_hw = False
        elif tag == 'pos':
            self.in_pos = False
        elif tag == 'def':
            self.in_def = False
        elif tag == 'sn':
            self.in_sn = False
        elif tag == 'plw':
            self.in_plw = False
        elif tag == 'u':
            self.in_u = False
        elif tag == 'grk':
            self.in_grk = False
        elif tag == 'blockquote':
            if self.current_quote:
                self.current_quote['text'] = ' '.join(self.current_quote['text'].split())
                self.current_quote['source'] = ' '.join(self.current_quote['source'].split())
                if self.current_sense is not None:
                    self.current_sense['quotes'].append(self.current_quote)
                else:
                    self.result['quotes'].append(self.current_quote)
            self.current_quote = None
        elif tag == 'col':
            self._close_collocation()
        elif tag == 'cd':
            pass

    def handle_data(self, data):
        # Italics handling
        if 'i' in self.tag_stack:
            # inside <blockquote> italics -> source/citation
            if self.current_quote is not None:
                self.current_quote['source'] += data
                return
            # italics inside <def> are definition text
            if self.in_def:
                self._route(data)
                return
            # italics before any <def> and not in hw/pos -> etymology
            if not self.in_hw and not self.in_pos and not self.in_def \
                    and self.current_sense is None and self.current_collocation is None:
                self.in_etymology = True
                self.result['etymology'] += data
                return
            # otherwise append normally
            self._route(data)
            return

        # collocation phrase text
        if self.current_collocation is not None and 'col' in self.tag_stack:
            self.current_collocation['phrase'] += data
            return

        self._route(data)

    # -------- finalisation --------
    def finish(self):
        self._close_sense()
        self._close_collocation()
        for key in ('word', 'pronunciation', 'part_of_speech',
                    'etymology', 'definition'):
            self.result[key] = ' '.join(self.result[key].split())
        self.result['notes'] = [n for n in self.result['notes'] if n]
        return self.result


def parse_file(path):
    with open(path, encoding='utf-8') as f:
        raw = f.read()

    # Split into (page_number, chunk) segments at page markers
    segments = []
    last = 0
    current_page = None
    for m in PAGE_MARKER.finditer(raw):
        segments.append((current_page, raw[last:m.start()]))
        current_page = int(m.group(1))
        last = m.end()
    segments.append((current_page, raw[last:]))

    entries = []          # finished entries
    current = None        # entry being built

    for page, chunk in segments:
        for p_match in re.finditer(r'<p>(.*?)</p>', chunk, re.DOTALL):
            body = p_match.group(1).strip()
            if not body or re.fullmatch(r'<!\s*.*?\s*!>', body):
                continue

            parser = ParagraphParser()
            parser.feed('<p>' + body + '</p>')
            para = parser.finish()

            # Skip point markers like <point26>A.</point26>
            if para['is_point']:
                continue

            # A new <hw> paragraph starts a new entry
            if para['has_hw']:
                if current is not None:
                    entries.append(current)
                current = {
                    'word': para['word'],
                    'pronunciation': para['pronunciation'],
                    'part_of_speech': para['part_of_speech'],
                    'etymology': para['etymology'],
                    'senses': list(para['senses']),
                    'collocations': list(para['collocations']),
                    'quotes': list(para['quotes']),
                    'notes': list(para['notes']),
                    'page': page,
                }
                # First <def> becomes sense 1 if no sense was registered
                if para['definition']:
                    if current['senses']:
                        # a numbered sense already existed; prepend unnumbered body
                        current['senses'].insert(0, {
                            'number': '1',
                            'text': para['definition'],
                            'quotes': [],
                        })
                    else:
                        current['senses'].append({
                            'number': '1',
                            'text': para['definition'],
                            'quotes': [],
                        })
                continue

            # Otherwise attach to the current entry
            if current is None:
                # stray paragraph before any headword — keep as standalone note
                current = {
                    'word': '',
                    'pronunciation': '',
                    'part_of_speech': '',
                    'etymology': '',
                    'senses': [],
                    'collocations': [],
                    'quotes': [],
                    'notes': [para['definition']] if para['definition'] else [],
                    'page': page,
                }
                if para['senses']:
                    current['senses'].extend(para['senses'])
                if para['collocations']:
                    current['collocations'].extend(para['collocations'])
                if para['quotes']:
                    current['quotes'].extend(para['quotes'])
                continue

            if para['definition']:
                # continuation paragraph of a sense
                if current['senses']:
                    current['senses'][-1]['text'] += ' ' + para['definition']
                    current['senses'][-1]['text'] = \
                        ' '.join(current['senses'][-1]['text'].split())
                else:
                    current['senses'].append({
                        'number': None,
                        'text': para['definition'],
                        'quotes': [],
                    })
            current['senses'].extend(para['senses'])
            current['collocations'].extend(para['collocations'])
            current['quotes'].extend(para['quotes'])
            current['notes'].extend(para['notes'])

    if current is not None:
        entries.append(current)

    return entries


def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <input_file>")
        sys.exit(1)

    entries = parse_file(sys.argv[1])
    out = sys.argv[1].rsplit('.', 1)[0] + '.json'
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(entries, f, indent=2, ensure_ascii=False)

    print(f"Wrote {len(entries)} entries to {out}")
    # Print the first two real entries as a sanity check
    shown = 0
    for e in entries:
        if e['word']:
            print('\n---', e['word'], '---')
            print(json.dumps(e, indent=2, ensure_ascii=False)[:1200])
            shown += 1
            if shown >= 2:
                break


if __name__ == '__main__':
    main()
